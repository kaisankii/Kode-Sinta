# KODE / CSMS

Source-code bundle prepared for GitHub and code review.

## Contents
- `csms/main.py`, `main_v2.py`, `main_v3.py`: backend variants (kept as provided; not assumed to be interchangeable).
- `csms/plate.py`: Indonesian license-plate normalization helpers.
- `csms/static/daftar.html`: frontend page.
- `csms-deploy/`: deployment configuration and helper scripts.
- `API_DOCUMENTATION.md`: API documentation.

## Excluded generated/local files
- `venv/`, Python caches, and `.DS_Store`: local environment/cache files.
- `cloudflared` and `cloudflared.tgz`: large downloaded tunnel binary/archive; install separately if needed.
- `csms.db`: local SQLite database, omitted because it may contain real or sensitive data. The app may create a fresh database at runtime.

## Before publishing
Review the code and `.env.example` for secrets or private information. Never commit a real `.env`, API keys, tokens, passwords, or sensitive database contents.
