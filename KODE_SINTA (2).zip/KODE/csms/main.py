import hashlib
import hmac
import os
import sqlite3
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import List, Optional

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, field_validator

from plate import parse_plate, plate_key

DB = "csms.db"

# Kunci rahasia hash NIK. HARUS sama di mana pun backend berjalan.
SECRET = os.environ.get("NIK_SECRET", "ganti-ini-saat-produksi").encode()
# Kunci yang harus dikirim edge device di header X-API-Key.
EDGE_API_KEY = os.environ.get("EDGE_API_KEY", "dev-edge-key")

CONF_MIN = 0.6        # di bawah ini, plat dianggap tidak terbaca jelas
DEDUP_DETIK = 30      # kejadian identik dalam rentang ini tidak dicatat dua kali
SLOT_AWAL = ["SLOT_A1", "SLOT_A2"]
MAKS_KENDARAAN = 5    # batas jumlah plat per NIK (cegah penyalahgunaan)
TIPE_EV = "BEV"       # hanya kendaraan listrik murni (BEV) yang boleh mendaftar

# Di server produksi, set MATIKAN_DOCS=1 agar halaman /docs tidak terbuka untuk umum.
_docs_mati = bool(os.environ.get("MATIKAN_DOCS"))
app = FastAPI(title="CSMS Hub",
              docs_url=None if _docs_mati else "/docs",
              redoc_url=None,
              openapi_url=None if _docs_mati else "/openapi.json")


# ---------------------------------------------------------------- database
def koneksi():
    con = sqlite3.connect(DB, timeout=10)
    con.execute("PRAGMA foreign_keys = ON")
    return con


def init_db():
    con = koneksi()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS pengguna (
        id_pengguna TEXT PRIMARY KEY,
        nik_hash TEXT UNIQUE NOT NULL,
        nama TEXT NOT NULL,
        nip_nim TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'civitas_itb',
        status_verifikasi TEXT NOT NULL DEFAULT 'pending',
        tgl_registrasi TEXT NOT NULL,
        tgl_verifikasi TEXT
    );
    CREATE TABLE IF NOT EXISTS kendaraan (
        id_kendaraan TEXT PRIMARY KEY,
        id_pengguna TEXT NOT NULL REFERENCES pengguna(id_pengguna),
        plat_nomor TEXT NOT NULL,
        plat_key TEXT UNIQUE NOT NULL,
        tipe_ev TEXT NOT NULL,
        status_aktif INTEGER NOT NULL DEFAULT 1,
        tgl_daftar TEXT NOT NULL,
        status_verifikasi TEXT NOT NULL DEFAULT 'pending',
        tgl_verifikasi TEXT
    );
    CREATE TABLE IF NOT EXISTS slot_parkir (
        id_slot TEXT PRIMARY KEY,
        status_slot TEXT NOT NULL DEFAULT 'kosong',
        last_updated TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS csms_session (
        id_sesi TEXT PRIMARY KEY,
        id_pengguna TEXT NOT NULL REFERENCES pengguna(id_pengguna),
        id_kendaraan TEXT NOT NULL REFERENCES kendaraan(id_kendaraan),
        id_slot TEXT NOT NULL REFERENCES slot_parkir(id_slot),
        waktu_masuk TEXT NOT NULL,
        waktu_keluar TEXT,
        durasi_menit REAL,
        kwh_tersalurkan REAL,
        status_sesi TEXT NOT NULL DEFAULT 'aktif'
    );
    CREATE TABLE IF NOT EXISTS log_akses (
        id_log TEXT PRIMARY KEY,
        id_pengguna TEXT REFERENCES pengguna(id_pengguna),
        id_kendaraan TEXT REFERENCES kendaraan(id_kendaraan),
        id_slot TEXT NOT NULL REFERENCES slot_parkir(id_slot),
        waktu_akses TEXT NOT NULL,
        waktu_tangkap TEXT,
        sumber_autentikasi TEXT NOT NULL DEFAULT 'anpr',
        decision TEXT NOT NULL,
        status_autentikasi TEXT NOT NULL,
        plat_terbaca TEXT,
        plat_key TEXT,
        confidence REAL,
        ev_hint INTEGER,
        corrected INTEGER NOT NULL DEFAULT 0,
        latency_ms REAL,
        edge_id TEXT
    );
    """)
    # Migrasi database lama: verifikasi KTP kini dicatat per KENDARAAN, bukan per pengguna.
    kolom = [r[1] for r in con.execute("PRAGMA table_info(kendaraan)")]
    if "status_verifikasi" not in kolom:
        con.execute("ALTER TABLE kendaraan ADD COLUMN status_verifikasi TEXT NOT NULL DEFAULT 'pending'")
        con.execute("ALTER TABLE kendaraan ADD COLUMN tgl_verifikasi TEXT")
        con.execute("UPDATE kendaraan SET "
                    "status_verifikasi = (SELECT p.status_verifikasi FROM pengguna p "
                    "WHERE p.id_pengguna = kendaraan.id_pengguna), "
                    "tgl_verifikasi = (SELECT p.tgl_verifikasi FROM pengguna p "
                    "WHERE p.id_pengguna = kendaraan.id_pengguna)")
    t = iso(sekarang())
    for s in SLOT_AWAL:
        con.execute("INSERT OR IGNORE INTO slot_parkir (id_slot, last_updated) VALUES (?,?)", (s, t))
    con.commit()
    con.close()


def sekarang():
    return datetime.now(timezone.utc)


def iso(dt):
    return dt.isoformat(timespec="milliseconds")


init_db()


def hash_nik(nik: str) -> str:
    return hmac.new(SECRET, nik.encode(), hashlib.sha256).hexdigest()


def cek_kunci(x_api_key: Optional[str] = Header(default=None)):
    if not x_api_key or not hmac.compare_digest(x_api_key.encode(), EDGE_API_KEY.encode()):
        raise HTTPException(401, "API key salah atau tidak ada")


# ---------------------------------------------------------------- registrasi
class KendaraanBaru(BaseModel):
    plat: str


class Registrasi(BaseModel):
    nik: str
    nama: str
    nip_nim: str
    kendaraan: List[KendaraanBaru]
    consent: bool

    @field_validator("nik")
    @classmethod
    def cek_nik(cls, v):
        v = v.strip()
        if not (v.isdigit() and len(v) == 16):
            raise ValueError("NIK harus 16 digit angka")
        return v

    @field_validator("nama", "nip_nim")
    @classmethod
    def cek_isi(cls, v):
        v = v.strip()
        if len(v) < 2:
            raise ValueError("Nama dan NIP/NIM wajib diisi")
        return v

    @field_validator("kendaraan")
    @classmethod
    def cek_kendaraan(cls, v):
        if not 1 <= len(v) <= MAKS_KENDARAAN:
            raise ValueError(f"Isi 1 sampai {MAKS_KENDARAAN} kendaraan")
        return v

    @field_validator("consent")
    @classmethod
    def cek_consent(cls, v):
        if not v:
            raise ValueError("Anda harus menyetujui penggunaan data")
        return v


@app.get("/daftar")
def halaman_daftar():
    return FileResponse("static/daftar.html")


@app.post("/api/v1/register", status_code=201)
def register(data: Registrasi):
    # Plat diketik manusia: jangan auto-koreksi diam-diam. Minta periksa ulang.
    daftar, terlihat = [], set()
    for kd in data.kendaraan:
        parsed = parse_plate(kd.plat)
        if parsed is None or parsed[1] > 0:
            raise HTTPException(422, f"Format plat '{kd.plat}' tidak dikenali. Contoh: D 1137 AMK")
        if plate_key(parsed[0]) in terlihat:      # plat ganda dalam satu permintaan
            continue
        terlihat.add(plate_key(parsed[0]))
        daftar.append(parsed[0])

    waktu = iso(sekarang())
    con = koneksi()
    try:
        con.execute("BEGIN IMMEDIATE")
        row = con.execute("SELECT id_pengguna, nama FROM pengguna WHERE nik_hash=?",
                          (hash_nik(data.nik),)).fetchone()
        if row:
            # NIK sudah ada -> tambah kendaraan ke akun yang sama.
            if row[1].strip().lower() != data.nama.strip().lower():
                raise HTTPException(409, "Nama tidak cocok dengan pendaftaran sebelumnya untuk NIK ini")
            id_user, akun_baru = row[0], False
        else:
            id_user, akun_baru = str(uuid.uuid4()), True
            con.execute("INSERT INTO pengguna (id_pengguna, nik_hash, nama, nip_nim, tgl_registrasi) "
                        "VALUES (?,?,?,?,?)",
                        (id_user, hash_nik(data.nik), data.nama.strip(), data.nip_nim.strip(), waktu))

        jumlah = con.execute("SELECT COUNT(*) FROM kendaraan WHERE id_pengguna=?", (id_user,)).fetchone()[0]
        hasil = []
        for plat in daftar:
            key = plate_key(plat)
            ada = con.execute("SELECT id_pengguna FROM kendaraan WHERE plat_key=?", (key,)).fetchone()
            if ada:
                if ada[0] != id_user:
                    raise HTTPException(409, f"Plat {plat} sudah terdaftar atas akun lain")
                hasil.append({"plat": plat, "hasil": "sudah_ada"})
                continue
            if jumlah >= MAKS_KENDARAAN:
                raise HTTPException(409, f"Maksimal {MAKS_KENDARAAN} kendaraan per NIK")
            # Kendaraan baru SELALU mulai 'pending', walau pemiliknya sudah pernah verifikasi.
            # NIK bukan rahasia; tanpa ini orang lain bisa menempelkan plat ke akun terverifikasi.
            con.execute("INSERT INTO kendaraan (id_kendaraan, id_pengguna, plat_nomor, plat_key, tipe_ev, "
                        "tgl_daftar) VALUES (?,?,?,?,?,?)",
                        (str(uuid.uuid4()), id_user, plat, key, TIPE_EV, waktu))
            jumlah += 1
            hasil.append({"plat": plat, "hasil": "ditambahkan"})
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()

    return {"status": "pending", "akun_baru": akun_baru, "kendaraan": hasil}


# ---------------------------------------------------------------- ANPR
class DataANPR(BaseModel):
    slot_id: str
    plate_number: str
    confidence: float = Field(ge=0, le=1)
    ev_hint: Optional[bool] = None
    captured_at: Optional[str] = None
    edge_id: Optional[str] = None


def lcd(*baris):
    """Selalu 4 baris, maksimal 20 karakter per baris (LCD 20x4)."""
    b = [str(x)[:20] for x in baris][:4]
    while len(b) < 4:
        b.append("")
    return b


def putuskan(con, d: DataANPR) -> dict:
    """Inti keputusan. Dipanggil di dalam satu transaksi."""
    r = {"decision": "", "message": "", "session_id": None, "plate": "",
         "id_pengguna": None, "id_kendaraan": None, "corrected": False, "lcd": []}

    slot = con.execute("SELECT 1 FROM slot_parkir WHERE id_slot=?", (d.slot_id,)).fetchone()
    if not slot:
        raise HTTPException(404, f"slot_id '{d.slot_id}' tidak dikenal")

    # 1. Rapikan plat. Gagal parse atau confidence rendah -> minta ulang.
    parsed = parse_plate(d.plate_number)
    if parsed:
        r["plate"], fixes = parsed
        r["corrected"] = fixes > 0
    else:
        r["plate"] = d.plate_number.strip()[:20]
    if parsed is None or d.confidence < CONF_MIN:
        r.update(decision="low_confidence_retry", message="Plat tidak terbaca jelas",
                 lcd=lcd("PLAT TIDAK TERBACA", "MUNDUR SEDIKIT", "LALU COBA LAGI"))
        return r

    # 2. Kamera bilang bukan EV -> soft reject (tidak perlu disuruh daftar).
    if d.ev_hint is False:
        r.update(decision="soft_reject_non_ev", message="Terdeteksi bukan kendaraan listrik",
                 lcd=lcd("AKSES DITOLAK", "KHUSUS KENDARAAN", "LISTRIK (EV)", r["plate"]))
        return r

    # 3. Cari plat di database lewat plat_key (tanpa spasi).
    key = plate_key(r["plate"])
    row = con.execute(
        "SELECT id_kendaraan, id_pengguna, status_verifikasi FROM kendaraan "
        "WHERE plat_key=? AND status_aktif=1", (key,)).fetchone()
    if not row:
        r.update(decision="register_required", message="Plat belum terdaftar",
                 lcd=lcd("PLAT BELUM TERDAFTAR", "SCAN QR UNTUK", "DAFTAR", r["plate"]))
        return r
    r["id_kendaraan"], r["id_pengguna"] = row[0], row[1]

    # 4. Kendaraan ini belum diverifikasi lewat KTP fisik.
    if row[2] != "terverifikasi":
        r.update(decision="ktp_required", message="Perlu verifikasi KTP fisik",
                 lcd=lcd("VERIFIKASI KTP", "TUNJUKKAN KTP FISIK", "KE KAMERA", r["plate"]))
        return r

    # 5. Sesi aktif milik kendaraan ini? (pembacaan berulang = hasil sama)
    ses = con.execute("SELECT id_sesi, id_slot FROM csms_session "
                      "WHERE id_kendaraan=? AND status_sesi='aktif'", (r["id_kendaraan"],)).fetchone()
    if ses:
        if ses[1] == d.slot_id:
            r.update(decision="granted", session_id=ses[0], message="Sesi sudah aktif",
                     lcd=lcd("AKSES DITERIMA", r["plate"], d.slot_id.replace("_", " ")))
        else:
            r.update(decision="denied", message="Kendaraan sudah punya sesi aktif di slot lain",
                     lcd=lcd("SESI AKTIF DI", ses[1].replace("_", " "), r["plate"]))
        return r

    # 6. Slot dipakai kendaraan lain? Dilihat dari SESI, bukan status slot:
    #    status slot jadi 'terisi' begitu CV melihat mobil, termasuk mobil ini sendiri.
    lain = con.execute("SELECT 1 FROM csms_session WHERE id_slot=? AND status_sesi='aktif'",
                       (d.slot_id,)).fetchone()
    if lain:
        r.update(decision="slot_occupied", message="Slot sedang dipakai",
                 lcd=lcd("SLOT SEDANG DIPAKAI", d.slot_id.replace("_", " "), "GUNAKAN SLOT LAIN"))
        return r

    # 7. Lolos semua -> buat sesi, tandai slot terisi.
    waktu = iso(sekarang())
    id_sesi = str(uuid.uuid4())
    con.execute("INSERT INTO csms_session (id_sesi, id_pengguna, id_kendaraan, id_slot, waktu_masuk) "
                "VALUES (?,?,?,?,?)", (id_sesi, r["id_pengguna"], r["id_kendaraan"], d.slot_id, waktu))
    con.execute("UPDATE slot_parkir SET status_slot='terisi', last_updated=? WHERE id_slot=?",
                (waktu, d.slot_id))
    r.update(decision="granted", session_id=id_sesi, message="Akses diterima",
             lcd=lcd("AKSES DITERIMA", r["plate"], d.slot_id.replace("_", " ")))
    return r


def status_dari(decision: str) -> str:
    if decision == "granted":
        return "berhasil"
    if decision == "soft_reject_non_ev":
        return "rejected"
    return "gagal"


def catat_log(con, d: DataANPR, r: dict, latency_ms: float) -> bool:
    """Tulis Log_Akses. Kejadian identik dalam DEDUP_DETIK dilewati agar log tidak banjir."""
    key = plate_key(r["plate"])
    batas = iso(sekarang() - timedelta(seconds=DEDUP_DETIK))
    dup = con.execute("SELECT 1 FROM log_akses WHERE plat_key=? AND id_slot=? AND decision=? "
                      "AND waktu_akses>?", (key, d.slot_id, r["decision"], batas)).fetchone()
    if dup:
        return False
    con.execute(
        "INSERT INTO log_akses (id_log, id_pengguna, id_kendaraan, id_slot, waktu_akses, waktu_tangkap, "
        "decision, status_autentikasi, plat_terbaca, plat_key, confidence, ev_hint, corrected, "
        "latency_ms, edge_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (str(uuid.uuid4()), r["id_pengguna"], r["id_kendaraan"], d.slot_id, iso(sekarang()),
         d.captured_at, r["decision"], status_dari(r["decision"]), r["plate"], key, d.confidence,
         None if d.ev_hint is None else int(d.ev_hint), int(r["corrected"]),
         round(latency_ms, 1), d.edge_id))
    return True


@app.post("/api/v1/auth/anpr", dependencies=[Depends(cek_kunci)])
def auth_anpr(d: DataANPR):
    t0 = time.perf_counter()
    con = koneksi()
    try:
        con.execute("BEGIN IMMEDIATE")      # cegah dua permintaan membuat sesi ganda
        r = putuskan(con, d)
        latency = (time.perf_counter() - t0) * 1000
        catat_log(con, d, r, latency)
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()
    return {"decision": r["decision"], "message": r["message"], "session_id": r["session_id"],
            "plate": r["plate"], "lcd": r["lcd"], "latency_ms": round(latency, 1)}


# ---------------------------------------------------------------- endpoint bantu
class AkhiriSesi(BaseModel):
    kwh_final: Optional[float] = None


@app.patch("/api/v1/session/{id_sesi}/end", dependencies=[Depends(cek_kunci)])
def akhiri_sesi(id_sesi: str, body: Optional[AkhiriSesi] = None):
    con = koneksi()
    try:
        row = con.execute("SELECT id_slot, waktu_masuk, status_sesi FROM csms_session WHERE id_sesi=?",
                          (id_sesi,)).fetchone()
        if not row:
            raise HTTPException(404, "Sesi tidak ditemukan")
        if row[2] != "aktif":
            raise HTTPException(409, "Sesi sudah selesai")
        sekarang_dt = sekarang()
        durasi = (sekarang_dt - datetime.fromisoformat(row[1])).total_seconds() / 60
        kwh = body.kwh_final if body else None
        con.execute("UPDATE csms_session SET status_sesi='selesai', waktu_keluar=?, durasi_menit=?, "
                    "kwh_tersalurkan=? WHERE id_sesi=?", (iso(sekarang_dt), round(durasi, 2), kwh, id_sesi))
        con.execute("UPDATE slot_parkir SET status_slot='kosong', last_updated=? WHERE id_slot=?",
                    (iso(sekarang_dt), row[0]))
        con.commit()
    finally:
        con.close()
    return {"id_sesi": id_sesi, "durasi_menit": round(durasi, 2), "kwh_tersalurkan": kwh}


@app.get("/api/v1/slots", dependencies=[Depends(cek_kunci)])
def daftar_slot():
    con = koneksi()
    try:
        rows = con.execute("SELECT id_slot, status_slot, last_updated FROM slot_parkir "
                           "ORDER BY id_slot").fetchall()
    finally:
        con.close()
    return {"slots": [{"id": a, "status": b, "last_updated": c} for a, b, c in rows]}


@app.get("/api/v1/log/akses", dependencies=[Depends(cek_kunci)])
def daftar_log(limit: int = 20):
    limit = max(1, min(limit, 200))
    con = koneksi()
    try:
        rows = con.execute("SELECT waktu_akses, id_slot, plat_terbaca, decision, confidence, corrected, "
                           "latency_ms FROM log_akses ORDER BY waktu_akses DESC LIMIT ?", (limit,)).fetchall()
    finally:
        con.close()
    kolom = ["waktu", "slot", "plat", "decision", "confidence", "corrected", "latency_ms"]
    return {"log": [dict(zip(kolom, r)) for r in rows]}