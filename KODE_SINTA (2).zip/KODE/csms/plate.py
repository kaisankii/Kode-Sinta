"""Normalisasi plat nomor Indonesia untuk backend CSMS.

Format kanonik (disimpan & ditampilkan): "D 1137 AMK"
  - 1-2 huruf kode wilayah, 1-4 angka, 0-3 huruf seri.
Kunci pencocokan (tanpa spasi): "D1137AMK"  -> pakai plate_key().

Output mentah fast-alpr / EasyOCR biasanya tanpa spasi ("D1137AMK"), jadi
backend yang bertugas memberi spasi dan memperbaiki salah-baca huruf/angka.
"""
import re

# Huruf yang salah dibaca sebagai angka (posisi huruf) dan sebaliknya (posisi angka).
# Catatan: tidak ada kode wilayah berawalan "O", jadi "0" di posisi huruf -> "D".
TO_LETTER = {"0": "D", "1": "I", "5": "S", "8": "B", "2": "Z", "6": "G"}
TO_DIGIT = {"O": "0", "D": "0", "Q": "0", "I": "1", "L": "1",
            "S": "5", "B": "8", "Z": "2", "G": "6"}


def normalize_plate(raw: str) -> str:
    """Huruf besar, buang semua selain A-Z dan 0-9."""
    return re.sub(r"[^A-Z0-9]", "", (raw or "").upper())


def plate_key(raw: str) -> str:
    """Kunci unik untuk pencocokan di DB (tanpa spasi)."""
    return normalize_plate(raw)


def _coerce(part: str, kind: str):
    """Paksa `part` menjadi huruf ('L') atau angka ('D'). Return (teks, jumlah_koreksi) / None."""
    out, fixes = "", 0
    for ch in part:
        if kind == "L":
            if ch.isalpha():
                out += ch
            elif ch in TO_LETTER:
                out += TO_LETTER[ch]
                fixes += 1
            else:
                return None
        else:
            if ch.isdigit():
                out += ch
            elif ch in TO_DIGIT:
                out += TO_DIGIT[ch]
                fixes += 1
            else:
                return None
    return out, fixes


def parse_plate(raw: str, prefixes=None):
    """Return (plat_berspasi, jumlah_koreksi) atau None jika bukan format plat Indonesia.

    prefixes: set kode wilayah valid (mis. {"D", "B", "AB", "DK"}). Jika diberikan,
    kandidat dengan awalan di luar set dibuang -> menyelesaikan kasus ambigu seperti
    "DI137AMK" (DI + 137 vs D + 1137). Isi dari daftar resmi kode wilayah Polri.
    """
    s = normalize_plate(raw)
    if not any(c.isalpha() for c in s):   # "12345" bukan plat, jangan dipaksa jadi huruf
        return None
    best = None
    for p in (1, 2):
        for d in range(1, 5):
            t = len(s) - p - d
            if not 0 <= t <= 3:
                continue
            parts = []
            total = 0
            for seg, kind in ((s[:p], "L"), (s[p:p + d], "D"), (s[p + d:], "L")):
                res = _coerce(seg, kind)
                if res is None:
                    break
                parts.append(res[0])
                total += res[1]
            else:
                if prefixes is not None and parts[0] not in prefixes:
                    continue
                if best is None or total < best[0]:
                    best = (total, parts)
    if best is None:
        return None
    fixes, (pre, mid, suf) = best
    return " ".join(x for x in (pre, mid, suf) if x), fixes


if __name__ == "__main__":
    cases = {
        "D1137AMK": "D 1137 AMK",
        "D 1137 AMK": "D 1137 AMK",
        "AB1287KP": "AB 1287 KP",
        "B1234": "B 1234",
        "01137AMK": "D 1137 AMK",   # '0' di posisi huruf -> D
        "B 12O4 XYZ": "B 1204 XYZ",
        "12345": None,
        "": None,
    }
    for raw, want in cases.items():
        got = parse_plate(raw)
        got = got[0] if got else None
        print(f"{raw!r:14} -> {got!r:14} {'OK' if got == want else 'GAGAL (harusnya ' + repr(want) + ')'}")

    # Kasus ambigu: tanpa whitelist "DI 137 AMK" lolos; dengan whitelist jadi benar.
    demo = {"D", "B", "AB", "DK"}
    print("DI137AMK tanpa whitelist :", parse_plate("DI137AMK"))
    print("DI137AMK dengan whitelist:", parse_plate("DI137AMK", prefixes=demo))
