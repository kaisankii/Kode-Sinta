   #!/bin/bash
   cd ~/csms
   source venv/bin/activate
   export NIK_SECRET="GANTI-DENGAN-TEKS-ACAK-PANJANG"
   export EDGE_API_KEY="GANTI-DENGAN-KEY-ACAK-PANJANG"
   export MATIKAN_DOCS=1
   uvicorn main:app --host 127.0.0.1 --port 8000