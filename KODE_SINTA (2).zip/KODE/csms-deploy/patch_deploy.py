"""
Siapkan main.py untuk server (Docker + InfluxDB).
Jalankan dari folder csms SETELAH upgrade_csms.py:   python3 patch_deploy.py
main.py dicadangkan ke main.py.deploy.bak dan dikembalikan kalau hasilnya error.
"""
import os
import shutil
import subprocess
import sys

FILE = "main.py"
if not os.path.exists(FILE):
    sys.exit("Jalankan dari folder csms (yang berisi main.py).")
src = open(FILE, encoding="utf-8").read()
if "influx_log" in src:
    sys.exit("main.py sudah pernah diubah. Tidak ada yang dilakukan.")

GANTI = [
    ('''from inercharge import status_slot
''',
     '''from inercharge import status_slot
from influx_log import kirim_event
'''),
    ('''DB = "csms.db"''',
     '''DB = os.environ.get("CSMS_DB", "csms.db")'''),
    ('''    return {"decision": r["decision"], "message": r["message"], "session_id": r["session_id"],''',
     '''    kirim_event(d.slot_id, r["decision"], d.confidence, latency, d.edge_id)
    return {"decision": r["decision"], "message": r["message"], "session_id": r["session_id"],'''),
]
for lama, baru in GANTI:
    if src.count(lama) != 1:
        sys.exit("TIDAK COCOK, tidak ada yang diubah. Bagian ini tidak ditemukan persis di main.py "
                 "(sudah menjalankan upgrade_csms.py?):\n\n" + lama)
    src = src.replace(lama, baru)

shutil.copy(FILE, FILE + ".deploy.bak")
open(FILE, "w", encoding="utf-8").write(src)
if subprocess.run([sys.executable, "-m", "py_compile", FILE]).returncode != 0:
    shutil.copy(FILE + ".deploy.bak", FILE)
    sys.exit("Hasil perubahan error, main.py dikembalikan seperti semula.")
print("Selesai. main.py siap untuk server (cadangan: main.py.deploy.bak).")
