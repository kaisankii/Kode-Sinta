"""Kirim satu titik data ke InfluxDB 2.x. Kalau Influx belum diatur atau mati, diam saja."""
import os
import threading

import requests

URL = os.environ.get("INFLUX_URL")
TOKEN = os.environ.get("INFLUX_TOKEN")
ORG = os.environ.get("INFLUX_ORG")
BUCKET = os.environ.get("INFLUX_BUCKET", "csms")


def _esc(s):
    return str(s).replace("\\", "\\\\").replace(" ", "\\ ").replace(",", "\\,").replace("=", "\\=")


def kirim_event(slot, decision, confidence, latency_ms, edge_id=None):
    """Hanya data teknis. Plat, nama, dan NIK sengaja tidak dikirim."""
    if not (URL and TOKEN and ORG):
        return
    tags = f"slot={_esc(slot)},decision={_esc(decision)}"
    if edge_id:
        tags += f",edge={_esc(edge_id)}"
    baris = f"anpr_event,{tags} confidence={float(confidence)},latency_ms={float(latency_ms)}"

    def _kirim():
        try:
            requests.post(f"{URL}/api/v2/write", params={"org": ORG, "bucket": BUCKET},
                          headers={"Authorization": f"Token {TOKEN}"}, data=baris, timeout=2)
        except requests.RequestException:
            pass

    threading.Thread(target=_kirim, daemon=True).start()
