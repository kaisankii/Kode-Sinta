# Dokumentasi API — Inercharge (SPKLU ITB)

Base URL:
```
https://fti-itb.inercharge.id/api/
```

Semua endpoint di bawah relatif terhadap base URL itu (contoh: `get-live-status`
berarti `https://fti-itb.inercharge.id/api/get-live-status`).

## Daftar Isi

1. [Format umum response](#1-format-umum-response)
2. [Charge point — status & lokasi](#2-charge-point--status--lokasi)
3. [Riwayat transaksi & grafik (dashboard)](#3-riwayat-transaksi--grafik-dashboard)
4. [Ringkasan jaringan (overview)](#4-ringkasan-jaringan-overview)
5. [Heatmap & analisis utilisasi](#5-heatmap--analisis-utilisasi)
6. [Deteksi anomali (AI monitoring)](#6-deteksi-anomali-ai-monitoring)
7. [CCTV parkir](#7-cctv-parkir)
8. [Catatan penting & keterbatasan](#8-catatan-penting--keterbatasan)

---

## 1. Format umum response

Semua endpoint (kecuali `parking-stream`, yang balikan gambar JPEG langsung)
membalas JSON dengan pola yang sama:

**Sukses:**
```json
{ "status": "success", "...": "field lain sesuai endpoint" }
```

**Gagal:**
```json
{ "status": "error", "message": "penjelasan errornya" }
```

Selalu cek `status` dulu sebelum membaca field lain — jangan asumsikan field
data selalu ada kalau `status` bukan `"success"`.

Metode default semua endpoint adalah **GET** kecuali disebutkan lain
(`register`, `login`, `claim-session`, `resolve-anomaly` pakai **POST** dengan
body JSON).

---

## 2. Charge point — status & lokasi

### `GET /api/get-cp-list`
Daftar semua `cp_id` yang terdaftar.
```json
{ "status": "success", "data": ["Bender", "CP-DUMMY-01", "CP-DUMMY-02"] }
```

### `GET /api/get-live-status`
Status semua charge point + semua connector-nya sekaligus (dipakai halaman
Live Status). Setiap CP diasumsikan punya 2 connector.
```json
{
  "status": "success",
  "data": [
    {
      "cp_id": "Bender",
      "connectors": [
        {
          "id": 1,
          "status": "Charging",
          "trx_id": 333,
          "start": "2026-09-03T11:39:53",
          "power": 7.049,
          "energy": 0.34,
          "cost": 838,
          "voltage": 227.0,
          "current": 6.0
        },
        { "id": 2, "status": "Available", "power": 0, "energy": 0, "cost": 0, "voltage": 0, "current": 0 }
      ]
    }
  ]
}
```

### `GET /api/get-connector-status?cp_id=<id>&connector_id=<1|2>`
Status **satu** connector saja — dipakai halaman monitoring per-QR
(`/monitor`). `cp_id` dan `connector_id` wajib diisi (400 kalau tidak).
```json
{
  "status": "success",
  "data": {
    "status": "Charging",
    "cp_id": "Bender",
    "connector_id": 1,
    "trx_id": 333,
    "start": "2026-09-03T11:39:53",
    "duration_mins": 36.5,
    "power": 7.049,
    "energy": 0.34,
    "cost": 838,
    "voltage": 227.0,
    "current": 6.0
  }
}
```
Kalau connector sedang tidak dipakai, `data` cuma berisi
`{"status": "Available", "cp_id": ..., "connector_id": ...}` (field lain
tidak ada, bukan `0`/`null` — cek `status` dulu).

### `GET /api/get-cp-locations`
Charge point yang **sudah diisi koordinat** (lat/long) oleh admin — untuk
peta. CP yang belum ada koordinatnya **tidak muncul** di sini sama sekali.
```json
{
  "status": "success",
  "data": [
    {
      "cp_id": "CP-DUMMY-01",
      "latitude": -6.8907974,
      "longitude": 107.6096529,
      "location_name": "FTI, Kampus ITB",
      "available_connectors": 1,
      "total_connectors": 2
    }
  ]
}
```

---

## 3. Riwayat transaksi & grafik (dashboard)

Dipakai halaman Analytics/Transaction/Load Profile — filter umum lewat query
string `cp_id` (default `"all"`), `start`, `end` (format `YYYY-MM-DD`).

### `GET /api/get-transactions?cp_id=&start=&end=`
Daftar ID transaksi yang cocok filter (untuk dropdown pilihan transaksi).
```json
{ "status": "success", "data": [333, 332, 331] }
```

### `GET /api/get-data?cp_id=&start=&end=&transaction_id=`
Data grafik daya per-menit + ringkasan energi untuk filter/transaksi
tertentu. `transaction_id` opsional (default `"all"`).
```json
{
  "status": "success",
  "chart_series": [
    { "name": "Trx 333", "data": [["2026-09-03T11:40:00", 7.05], ["2026-09-03T11:41:00", 6.98]] }
  ],
  "summary": { "total_energy": 12.34, "total_transactions": 3, "peak_power": 7.4, "avg_power": 5.1 }
}
```

### `GET /api/get-table-data?cp_id=&start=&end=&mode=`
Tabel ringkasan transaksi (dipakai halaman Transaction). `mode=all` untuk
abaikan filter tanggal, selain itu filter berlaku sesuai `start`/`end`.
```json
{
  "status": "success",
  "summary": { "energy": 45.6, "cost": 112430, "count": 12 },
  "table": [
    {
      "id": 333, "cp": "Bender",
      "start": "2026-09-03 11:39:53", "end": "-",
      "kwh": 0.34, "cost": 838, "duration_mins": 36.5,
      "status": "Charging"
    }
  ]
}
```
Sesi yang masih berjalan: `end` = `"-"`, `status` = `"Charging"`.

### `GET /api/get-report-data?cp_id=&start=&end=`
Load profile (grafik total daya gabungan per-menit) + ringkasan energi untuk
periode tertentu (halaman Load Profile).
```json
{
  "status": "success",
  "data": [["2026-09-03T11:40:00", 7.05], ["2026-09-03T11:41:00", 13.2]],
  "summary": { "total_energy": 45.6, "peak_power": 7.4, "avg_power": 5.1 }
}
```

---

## 4. Ringkasan jaringan (overview)

### `GET /api/get-overview-data`
Ringkasan menyeluruh untuk halaman utama (Overview) — jumlah stasiun,
breakdown status connector, statistik sesi 30 hari terakhir, chart transaksi
14 hari terakhir, dan ringkasan anomali terbaru.
```json
{
  "status": "success",
  "network": { "total_stations": 3, "total_connectors": 6, "breakdown": [4, 2, 0] },
  "sessions": { "total_trx_count": 58, "zero_kwh": 3, "long_sessions": 1, "avg_duration": 187.4, "avg_energy": 4.2 },
  "chart": { "categories": ["2026-08-25", "2026-08-26"], "series": [4, 6] },
  "anomaly_summary": { "active": 1, "resolved_today": 2, "total_7days": 9 },
  "recent_anomalies": [
    { "id": 41, "timestamp": "2026-09-03 12:08:23", "cp_id": "Bender", "connector": 1, "kategori": "Overstay", "durasi": 1055.1, "kwh": 14.235, "power": 1.36, "tindakan": "Kirim notifikasi ke pengguna RFID...", "severity": "warning", "layer": "rule_based" }
  ]
}
```
`network.breakdown` urutannya tetap: `[Available, Charging, Faulted]`.

---

## 5. Heatmap & analisis utilisasi

### `GET /api/get-heatmap?date=YYYY-MM-DD`
Peta panas okupansi per-jam (0-23) tiap connector pada tanggal tertentu.
`0` = tidak dipakai, `1` = sedang charging di jam itu, `2` = jam sesi
berakhir.
```json
{
  "status": "success",
  "date": "2026-09-03",
  "data": { "Bender": { "1": [0,0,1,1,1,0,...], "2": [0,0,0,...] } }
}
```

### `GET /api/get-heatmap-analysis?date=YYYY-MM-DD`
Diagnosis otomatis tingkat utilisasi tiap connector pada tanggal itu
(underutilized/normal/highly utilized) + rekomendasi teks.
```json
{
  "status": "success",
  "date": "2026-09-03",
  "data": [
    { "cp": "Bender", "connector": "1", "utilization": 45.8, "unexpected": 1, "diagnosis": "Normal usage", "prediction": "Stable demand", "recommendation": "No immediate action required" }
  ]
}
```

---

## 6. Deteksi anomali (AI monitoring)

Sistem deteksi (rule-based EN 50160/IEC 61851-1 + Isolation Forest) berjalan
otomatis di background (service terpisah, scan tiap 60 detik) dan menulis ke
tabel `anomaly_logs`. Endpoint di bawah cuma baca/tulis tabel itu.

### `GET /api/get-anomaly-summary`
Ringkasan singkat untuk badge notifikasi.
```json
{
  "status": "success",
  "summary": { "active": 1, "resolved_today": 2, "total_7days": 9 },
  "latest_active": [
    { "id": 41, "timestamp": "2026-09-03T12:08:23", "cp_id": "Bender", "connector": 1, "kategori": "Overstay", "severity": "warning", "layer": "rule_based", "tindakan": "..." }
  ]
}
```

### `GET /api/get-anomaly-history?period=<today|7days|30days|all>&status=<active|resolved|all>`
Riwayat lengkap untuk tabel di halaman Diagnosis. Default `period=7days`,
`status=all`.
```json
{
  "status": "success",
  "count": 1,
  "data": [
    {
      "id": 41, "timestamp": "2026-09-03 12:08:23", "cp_id": "Bender", "connector": 1,
      "kategori": "Overstay", "durasi": 1055.1, "kwh": 14.235, "power": 1.36,
      "tindakan": "...", "status": "resolved", "severity": "warning", "layer": "rule_based",
      "score": null, "resolved_at": "2026-09-03 12:19:53", "resolved_note": "Charger reset, ditutup manual"
    }
  ]
}
```

### `POST /api/resolve-anomaly`
**Body:** `{ "id": 41, "note": "opsional" }`

Tandai anomali sebagai selesai ditangani. **Khusus kategori "Overstay"**:
resolve ini juga otomatis menutup transaksi yang jadi subjek anomali itu
(mengisi `stop_ts`/`meter_stop` dari pembacaan meter terakhir yang tercatat).
```json
{ "status": "success", "message": "Anomali #41 berhasil di-resolve. Transaksi yang overstay juga ditutup.", "transaction_closed": true }
```

### `GET /api/get-recent-anomalies`
5 anomali terbaru (semua status), format ringkas.

---

## 7. CCTV parkir

Kamera memantau okupansi slot parkir via AI (deteksi mobil), snapshot
di-refresh tiap 60 detik — **bukan** live streaming. Fitur per-`cp_id` (satu
charge point bisa punya kamera sendiri, atau belum punya kamera sama sekali).

### `GET /api/parking-status/<cp_id>`
```json
{
  "status": "success",
  "camera_id": "CAM-01",
  "data": { "SLOT 1": false, "SLOT 2": true },
  "charging_summary": {
    "cp_id": "Bender", "occupied_count": 1, "charging_count": 1,
    "not_charging_count": 0, "insight": "Semua mobil yang parkir sedang charging"
  }
}
```
`data`: map nama slot → `true` (terisi) / `false` (kosong). `charging_summary`
**opsional**, cuma muncul kalau ada cross-reference data OCPP untuk cp_id itu.

Kalau `cp_id` belum punya kamera terdaftar → **HTTP 404**:
```json
{ "status": "error", "message": "Tidak ada kamera CCTV terdaftar untuk <cp_id>" }
```
Ini kondisi normal (banyak charge point memang belum ada kameranya), bukan
bug — jangan ditampilkan sebagai error rusak.

### `GET /api/parking-stream/<cp_id>`
Balikan gambar JPEG langsung (`Content-Type: image/jpeg`), bukan JSON.
Tambahkan query param timestamp tiap fetch ulang supaya tidak ke-cache
(`?t=<epoch_ms>`), refresh tiap ~60 detik (tidak perlu lebih cepat, frame-nya
memang tidak berubah lebih sering). Kalau `cp_id` belum punya kamera, endpoint
ini balikan JSON error (404) juga, bukan gambar.

---

## 8. Catatan penting & keterbatasan

- **`voltage`/`current`/`power` adalah pembacaan TERAKHIR**, bukan
  rata-rata — bisa berbeda cukup jauh dari nilai sesaat sebelumnya kalau
  charger baru saja naik/turun beban.
- **Field kosong pada sesi yang masih berjalan** (`end`, `meter_stop`, dsb)
  konsisten `null` (bukan `0` atau string kosong) — cek `status`/nilai null
  eksplisit, jangan asumsikan tipe data selalu sama.
- **404 pada CCTV bukan berarti error** — banyak charge point memang belum
  dipasangi kamera.
